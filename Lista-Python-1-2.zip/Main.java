import java.util.Scanner;
  class Main {
  public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    System.out.println("digite um numero: ");
    int numero = teclado.nextInt();
    System.out.println("o numero digitado foi " + numero);
  }
}